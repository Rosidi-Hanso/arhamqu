
import React from 'react';
import { Trophy, Target, Calendar, Award, ChevronLeft, TrendingUp, BookOpen, Clock, Star, MapPin, X, ArrowUpRight } from 'lucide-react';
import { ProgressRecord, Grade } from '../types';

interface ProgressDashboardProps {
  records: ProgressRecord[];
  onClose: () => void;
}

const getGradeColor = (grade: Grade) => {
  switch (grade) {
    case 'A': return 'text-emerald-500 bg-emerald-50 border-emerald-200';
    case 'B': return 'text-blue-500 bg-blue-50 border-blue-200';
    case 'C': return 'text-orange-500 bg-orange-50 border-orange-200';
    default: return 'text-gray-500 bg-gray-50 border-gray-200';
  }
};

export const ProgressDashboard: React.FC<ProgressDashboardProps> = ({ records, onClose }) => {
  const latestRecord = records[0];
  
  const averageGrade = records.length > 0 
    ? (records.reduce((acc, r) => acc + (r.grade === 'A' ? 4 : r.grade === 'B' ? 3 : r.grade === 'C' ? 2 : 1), 0) / records.length).toFixed(1)
    : "0.0";

  return (
    <div className="flex flex-col h-full bg-[#f8faf9] overflow-hidden font-sans">
      {/* Dynamic Hero Header */}
      <div className="p-6 md:p-12 bg-emerald-900 text-white shrink-0 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500 rounded-full -translate-y-1/2 translate-x-1/2 opacity-10 blur-[100px]"></div>
        <div className="absolute bottom-0 left-0 w-60 h-60 bg-yellow-400 rounded-full translate-y-1/2 -translate-x-1/2 opacity-5 blur-[80px]"></div>
        
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-4">
               <button onClick={onClose} className="p-3 bg-white/10 rounded-2xl hover:bg-white/20 transition-all border border-white/10">
                  <ChevronLeft className="w-6 h-6" />
               </button>
               <div>
                  <h2 className="font-black text-2xl md:text-3xl tracking-tighter uppercase">Capaian Halaqoh</h2>
                  <p className="text-[10px] md:text-xs font-bold text-emerald-300 tracking-[0.2em] uppercase mt-0.5 opacity-60">Statistik Belajar Anda</p>
               </div>
            </div>
            <X onClick={onClose} className="w-8 h-8 text-white/20 hover:text-white cursor-pointer transition-colors" />
          </div>

          {/* Stats Bar Responsive Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white/10 backdrop-blur-3xl p-6 rounded-[2.5rem] border border-white/10 shadow-2xl">
              <p className="text-[10px] font-black uppercase text-emerald-300 tracking-widest mb-1">Total Sesi</p>
              <div className="flex items-end gap-2">
                <p className="text-3xl font-black leading-none">{records.length}</p>
                <TrendingUp className="w-4 h-4 text-emerald-400 mb-1" />
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-3xl p-6 rounded-[2.5rem] border border-white/10 shadow-2xl">
              <p className="text-[10px] font-black uppercase text-yellow-300 tracking-widest mb-1">Rata-rata</p>
              <div className="flex items-end gap-2">
                <p className="text-3xl font-black leading-none">{averageGrade}</p>
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400 mb-1" />
              </div>
            </div>
            <div className="hidden md:block bg-white/10 backdrop-blur-3xl p-6 rounded-[2.5rem] border border-white/10 shadow-2xl">
              <p className="text-[10px] font-black uppercase text-blue-300 tracking-widest mb-1">Juz Selesai</p>
              <p className="text-3xl font-black leading-none">2</p>
            </div>
            <div className="hidden md:block bg-white/10 backdrop-blur-3xl p-6 rounded-[2.5rem] border border-white/10 shadow-2xl">
              <p className="text-[10px] font-black uppercase text-orange-300 tracking-widest mb-1">Status</p>
              <p className="text-3xl font-black leading-none">AKTIF</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-6xl mx-auto p-6 md:p-12 grid grid-cols-1 lg:grid-cols-3 gap-10">
          
          {/* Left Column: Target & Summary */}
          <div className="lg:col-span-1 space-y-8">
            {latestRecord ? (
              <div className="bg-white p-8 rounded-[3rem] shadow-xl shadow-emerald-900/5 border border-emerald-100 flex flex-col gap-6 animate-in slide-in-from-left duration-500">
                <div className="flex items-center gap-4">
                   <div className="w-14 h-14 bg-emerald-600 rounded-3xl flex items-center justify-center text-white shadow-xl shadow-emerald-600/30">
                     <Target className="w-7 h-7" />
                   </div>
                   <div>
                     <p className="text-[10px] font-black uppercase text-emerald-600 tracking-widest">Target Berikutnya</p>
                     <h3 className="text-xl font-black text-emerald-950 tracking-tight">{latestRecord.targetNext}</h3>
                   </div>
                </div>
                <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100/50">
                  <p className="text-xs font-bold text-emerald-700 italic">"Istiqomah adalah kunci keberhasilan menghafal Al-Quran."</p>
                </div>
                <button className="w-full py-4 bg-emerald-950 text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] hover:bg-black transition-all">Mulai Murojaah Sekarang</button>
              </div>
            ) : (
              <div className="bg-white p-10 rounded-[3rem] text-center border-2 border-dashed border-gray-100">
                 <Trophy className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                 <p className="text-xs font-black text-gray-300 uppercase tracking-widest">Belum ada target</p>
              </div>
            )}

            <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 p-8 rounded-[3rem] text-white shadow-2xl shadow-emerald-900/20 relative overflow-hidden group">
               <div className="relative z-10">
                  <h4 className="font-black text-lg mb-2">Tips Hari Ini</h4>
                  <p className="text-sm opacity-80 leading-relaxed font-medium italic">"Gunakan waktu fajar untuk menghafal ayat baru agar lebih cepat terserap dalam ingatan."</p>
               </div>
               <ArrowUpRight className="absolute -bottom-2 -right-2 w-24 h-24 text-white/10 transition-transform group-hover:scale-125 duration-500" />
            </div>
          </div>

          {/* Right Column: History List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between mb-4 px-2">
               <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-emerald-900" />
                  <h3 className="font-black text-emerald-950 text-sm md:text-base tracking-tighter uppercase">Riwayat Setoran</h3>
               </div>
               <span className="text-[9px] font-black bg-emerald-100 text-emerald-700 px-4 py-1.5 rounded-full uppercase tracking-widest">{records.length} SESI</span>
            </div>

            <div className="space-y-4">
              {records.map((record, idx) => (
                <div 
                  key={record.id} 
                  className="bg-white p-6 md:p-8 rounded-[2.5rem] border border-gray-100 hover:border-emerald-200 shadow-sm hover:shadow-xl hover:shadow-emerald-900/5 transition-all group animate-in slide-in-from-bottom-5 duration-500"
                  style={{ animationDelay: `${idx * 100}ms` }}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="flex items-center gap-5">
                      <div className={`w-16 h-16 rounded-[1.8rem] flex items-center justify-center font-black text-2xl border-4 shadow-inner transition-transform group-hover:scale-110 ${getGradeColor(record.grade)}`}>
                        {record.grade}
                      </div>
                      <div>
                        <h4 className="font-black text-gray-950 text-base md:text-lg leading-none tracking-tight mb-1.5">{record.surahName}</h4>
                        <div className="flex items-center gap-3 flex-wrap">
                           <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Ayat {record.verseRange}</span>
                           <span className="w-1 h-1 bg-gray-200 rounded-full"></span>
                           <div className="flex items-center gap-1.5 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                             <Award className="w-3 h-3 text-emerald-600" />
                             <span className="text-[8px] font-black text-emerald-700 uppercase tracking-widest">{record.type}</span>
                           </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col md:items-end">
                       <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
                          <Calendar className="w-3.5 h-3.5" /> {record.date}
                       </div>
                       <p className="text-[9px] font-black text-emerald-600/60 uppercase tracking-tighter">Bimbingan: {record.teacherName}</p>
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t border-gray-50 flex gap-4">
                    <div className="shrink-0 w-1 bg-emerald-500/20 rounded-full h-auto"></div>
                    <div className="flex-1">
                      <p className="text-[8px] font-black text-emerald-900 uppercase tracking-[0.2em] mb-2 opacity-40">Catatan Pengajar:</p>
                      <p className="text-xs md:text-sm text-gray-600 font-bold italic leading-relaxed">"{record.note}"</p>
                    </div>
                  </div>
                </div>
              ))}

              {records.length === 0 && (
                <div className="py-32 text-center bg-white rounded-[3rem] border-2 border-dashed border-gray-100">
                  <BookOpen className="w-16 h-16 text-gray-100 mx-auto mb-6" />
                  <p className="text-xs font-black text-gray-300 uppercase tracking-[0.3em]">Belum Ada Riwayat Sesi</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
