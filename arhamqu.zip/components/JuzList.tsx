
import React, { useState, useEffect } from 'react';
import { X, Loader2, LayoutList, ChevronRight, BookOpen } from 'lucide-react';
import { apiService } from '../services/apiService';

export const JuzList: React.FC = () => {
  const [selectedJuz, setSelectedJuz] = useState<number | null>(null);
  const [content, setContent] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);

  // Fungsi utilitas untuk mengubah angka ke angka Arab
  const toArabicNumber = (num: number) => {
    const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    return num.toString().split('').map(d => arabicDigits[parseInt(d)]).join('');
  };

  const loadJuzContent = async (juzNum: number) => {
    setLoading(true);
    try {
      const data = await apiService.getJuzDetail(juzNum);
      if (data && data.verses) {
        setContent(data.verses.map((v: any) => ({
          surah: v.meta?.surahName || 'Surah',
          surahNomor: v.number.inQuran,
          ayat: v.number.inSurah,
          arab: v.text.arab,
          translation: v.translation.id,
          isNewSurah: v.number.inSurah === 1
        })));
      } else {
        setContent([]);
      }
    } catch (err) {
      console.error(err);
      setContent([]);
    } finally {
      setLoading(false);
    }
  };

  const handleJuzClick = (juzNumber: number) => {
    setSelectedJuz(juzNumber);
    loadJuzContent(juzNumber);
  };

  const closeReader = () => {
    setSelectedJuz(null);
    setContent(null);
  };

  return (
    <div className="flex flex-col h-full bg-[#f8fafc] md:bg-gray-50 relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-orange-500/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-6 md:p-10 overflow-y-auto max-w-7xl mx-auto w-full custom-scrollbar">
        {Array.from({ length: 30 }, (_, i) => i + 1).map((juz, idx) => (
          <button
            key={juz}
            onClick={() => handleJuzClick(juz)}
            className="group relative h-48 bg-white rounded-[2rem] border border-gray-100 flex flex-col items-center justify-center hover:border-emerald-300 hover:shadow-2xl hover:shadow-emerald-900/10 transition-all duration-500 shadow-sm active:scale-[0.97] overflow-hidden animate-in fade-in slide-in-from-bottom-4"
            style={{ animationDelay: `${idx * 40}ms` }}
          >
            {/* Background Pattern Ornament */}
            <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-[0.07] transition-opacity duration-500">
               <BookOpen className="w-24 h-24 rotate-12" />
            </div>

            {/* Arabic Big Number Background */}
            <div className="absolute -left-2 -bottom-4 text-emerald-500/5 font-arabic text-[120px] font-bold select-none group-hover:text-emerald-500/10 transition-colors duration-500">
              {toArabicNumber(juz)}
            </div>

            <div className="relative z-10 flex flex-col items-center">
              <div className="mb-2">
                <span className="font-arabic text-4xl text-emerald-800 drop-shadow-sm group-hover:scale-110 transition-transform duration-500 block">
                  الجزء {toArabicNumber(juz)}
                </span>
              </div>
              
              <div className="flex flex-col items-center">
                <span className="text-sm font-black text-gray-400 uppercase tracking-[0.3em] group-hover:text-emerald-600 transition-colors">
                  Juz {juz}
                </span>
                <div className="w-10 h-1 bg-emerald-100 rounded-full mt-3 group-hover:w-20 group-hover:bg-emerald-500 transition-all duration-500"></div>
              </div>
            </div>

            <div className="absolute bottom-4 right-6 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 translate-x-4 transition-all duration-500 flex items-center gap-1 text-emerald-600 text-[10px] font-black uppercase tracking-widest">
              Baca Sekarang <ChevronRight className="w-3 h-3" />
            </div>
          </button>
        ))}
      </div>

      {selectedJuz && (
        <div className="absolute inset-0 bg-white z-[70] flex flex-col animate-in slide-in-from-right duration-300 md:rounded-[2.5rem] overflow-hidden shadow-2xl">
          {/* Header */}
          <div className="p-4 bg-[#1a4d36] text-white flex items-center justify-between shrink-0 sticky top-0 z-20 shadow-md">
            <div className="flex items-center gap-4">
              <button onClick={closeReader} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
                <X className="w-5 h-5" />
              </button>
              <div className="flex flex-col">
                <h2 className="font-black text-xs uppercase tracking-widest leading-none">JUZ {selectedJuz}</h2>
                <p className="font-arabic text-lg text-emerald-300 mt-1 leading-none">الجزء {toArabicNumber(selectedJuz)}</p>
              </div>
            </div>
            
            <button className="hidden md:flex items-center gap-2 bg-black/20 hover:bg-black/30 px-6 py-2 rounded-full border border-white/10 transition-all active:scale-95">
              <LayoutList className="w-4 h-4 text-emerald-300" />
              <span className="text-[10px] font-black tracking-widest uppercase">MODE DAFTAR AYAT</span>
            </button>

            <div className="w-10 md:hidden" />
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto relative p-6 md:p-12 bg-[#fcfdfd] custom-scrollbar">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center gap-4 text-[#1a4d36] py-32">
                <Loader2 className="w-12 h-12 animate-spin" />
                <p className="text-[10px] font-black tracking-widest uppercase animate-pulse">Menghimpun Ayat...</p>
              </div>
            ) : content && content.length > 0 ? (
              <div className="max-w-4xl mx-auto pb-20 space-y-20">
                {content.map((ayat: any, index: number) => {
                  const isNewSurah = index === 0 || ayat.isNewSurah;
                  return (
                    <div key={`${ayat.surah}-${ayat.ayat}-${index}`} className="flex flex-col">
                      {isNewSurah && (
                        <div className="mb-16 text-center animate-in fade-in slide-in-from-top duration-700">
                          <div className="py-6 px-16 bg-[#1a4d36] text-white rounded-3xl inline-block shadow-xl shadow-emerald-900/10">
                             <h3 className="text-3xl font-black font-arabic tracking-tight">{ayat.surah}</h3>
                          </div>
                          {ayat.ayat === 1 && ayat.surahNomor !== 1 && ayat.surahNomor !== 9 && (
                            <p className="font-arabic text-5xl text-emerald-900 mt-14 mb-10 drop-shadow-sm leading-relaxed">
                              بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ
                            </p>
                          )}
                        </div>
                      )}

                      <div className="relative group transition-all duration-500">
                        {/* Verse Badge */}
                        <div className="absolute -left-4 md:-left-16 top-0 z-10">
                           <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-[11px] font-black text-white shadow-lg shadow-emerald-500/30 border-2 border-white">
                             {toArabicNumber(ayat.ayat)}
                           </div>
                        </div>

                        {/* Arabic Text */}
                        <div className="flex justify-center md:justify-end mb-10 pr-2 md:pr-0">
                          <p className="font-arabic text-4xl md:text-6xl text-right leading-[5rem] md:leading-[6.5rem] text-gray-900 tracking-wide drop-shadow-sm transition-all group-hover:text-emerald-950">
                            {ayat.arab}
                          </p>
                        </div>

                        {/* Translation Card */}
                        <div className="flex justify-start md:justify-center w-full">
                           <div className="bg-white p-8 md:p-10 rounded-[2.5rem] border-l-[6px] border-emerald-400 shadow-[0_10px_40px_-15px_rgba(0,0,0,0.05)] w-full max-w-2xl transform transition-all duration-500 group-hover:-translate-y-1 group-hover:shadow-emerald-900/5">
                             <p className="text-gray-700 text-sm md:text-base leading-[1.8] font-medium tracking-tight">
                               {ayat.translation}
                             </p>
                           </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div className="py-24 text-center">
                   <p className="text-emerald-400 text-xs font-black tracking-[0.5em] uppercase italic opacity-40">Sadaqallahul 'Adzim</p>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-gray-400 py-32">
                <LayoutList className="w-20 h-20 mb-6 opacity-10" />
                <p className="font-bold text-center uppercase tracking-widest text-xs">Konten tidak ditemukan</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
