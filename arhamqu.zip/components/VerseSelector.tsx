
import React, { useState, useEffect } from 'react';
import { X, Loader2, ChevronDown } from 'lucide-react';
import { apiService } from '../services/apiService';
import { Verse, Surah, VerseRange } from '../types';

interface VerseSelectorProps {
  onClose: () => void;
  onSend: (range: VerseRange) => void;
}

export const VerseSelector: React.FC<VerseSelectorProps> = ({ onClose, onSend }) => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [loading, setLoading] = useState(false);
  const [maxVerses, setMaxVerses] = useState(0);
  
  const [fromAyat, setFromAyat] = useState<number>(1);
  const [toAyat, setToAyat] = useState<number>(1);

  useEffect(() => {
    const loadSurahs = async () => {
      const data = await apiService.getSurahs();
      setSurahs(data);
      if (data.length > 0) setSelectedSurah(data[0]);
    };
    loadSurahs();
  }, []);

  useEffect(() => {
    if (selectedSurah) {
      setMaxVerses(selectedSurah.jumlahAyat);
      setFromAyat(1);
      setToAyat(selectedSurah.jumlahAyat > 5 ? 5 : selectedSurah.jumlahAyat);
    }
  }, [selectedSurah]);

  const handleTampilkan = async () => {
    if (!selectedSurah) return;
    setLoading(true);
    try {
      const allVerses = await apiService.getVerses(selectedSurah.nomor);
      const selectedVerses = allVerses.filter(v => v.nomorAyat >= fromAyat && v.nomorAyat <= toAyat);
      
      onSend({
        from: fromAyat,
        to: toAyat,
        verses: selectedVerses,
        surahName: selectedSurah.namaLatin
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[300] flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white w-full max-w-sm rounded-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="px-6 py-4 flex items-center justify-between border-b border-gray-100">
          <h2 className="text-gray-800 font-bold text-lg">Pilih Ayat</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="relative">
            <select 
              className="w-full p-3 bg-white border border-blue-200 rounded-md text-gray-700 text-sm focus:outline-none focus:ring-1 focus:ring-blue-400 appearance-none pr-10"
              value={selectedSurah?.nomor || ''}
              onChange={(e) => {
                const s = surahs.find(sur => sur.nomor === parseInt(e.target.value));
                if (s) setSelectedSurah(s);
              }}
            >
              {surahs.map(s => (
                <option key={s.nomor} value={s.nomor}>
                  {s.nomor}. {s.namaLatin}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <input 
                type="number" 
                placeholder="Dari"
                min="1"
                max={maxVerses}
                className="w-full p-3 border border-gray-200 rounded-md text-sm focus:outline-none focus:border-blue-400"
                value={fromAyat}
                onChange={(e) => setFromAyat(Math.min(maxVerses, parseInt(e.target.value) || 1))}
              />
            </div>
            <div className="space-y-1">
              <input 
                type="number" 
                placeholder="Sampai"
                min={fromAyat}
                max={maxVerses}
                className="w-full p-3 border border-gray-200 rounded-md text-sm focus:outline-none focus:border-blue-400"
                value={toAyat}
                onChange={(e) => setToAyat(Math.min(maxVerses, parseInt(e.target.value) || fromAyat))}
              />
            </div>
          </div>

          <button 
            onClick={handleTampilkan}
            disabled={loading}
            className="w-full py-3.5 bg-[#28a745] text-white rounded-md font-bold text-sm hover:bg-[#218838] transition-all flex items-center justify-center gap-2 mt-2"
          >
            {loading ? <Loader2 className="animate-spin w-4 h-4" /> : 'Tampilkan'}
          </button>
        </div>
      </div>
    </div>
  );
};
