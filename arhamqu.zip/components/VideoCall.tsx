
import React, { useRef, useEffect, useState } from 'react';
import { PhoneOff, Mic, Video, Book, X, ChevronLeft, ChevronRight, Users, Target, Loader2, VolumeX, Eye, EyeOff } from 'lucide-react';
import { VerseRange, LearningMode, UserTarget, Contact } from '../types';
import { apiService } from '../services/apiService';

interface VideoCallProps {
  contactName: string;
  onEndCall: () => void;
  onOpenVerseSelector: () => void;
  receivedRange?: VerseRange;
  isUstadz?: boolean;
  isGroup?: boolean;
  participants?: Contact[];
  groupTargets?: Record<string, UserTarget>;
  currentTarget?: UserTarget | null;
}

export const VideoCall: React.FC<VideoCallProps> = ({ 
  contactName, 
  onEndCall, 
  onOpenVerseSelector, 
  receivedRange,
  isUstadz = false,
  isGroup = false,
  participants = [],
  groupTargets = {},
  currentTarget = null
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const lastTargetIdRef = useRef<string>(""); 
  
  const [micOn, setMicOn] = useState(true);
  const [videoOn, setVideoOn] = useState(true);
  const [mode, setMode] = useState<LearningMode>('tahsin');
  const [activeVerseIndex, setActiveVerseIndex] = useState(0);
  const [localRange, setLocalRange] = useState<VerseRange | undefined>(receivedRange);
  const [loadingTarget, setLoadingTarget] = useState(false);
  
  // State khusus simulasi sinkronisasi: Ustadz bisa menyembunyikan ayat di sisi peserta saat Tahfidz
  const [isAyatVisibleForParticipant, setIsAyatVisibleForParticipant] = useState(true);
  
  const [activeParticipantId, setActiveParticipantId] = useState<string | null>(() => {
    return isGroup && participants.length > 0 ? participants[0].id : null;
  });

  useEffect(() => {
    let stream: MediaStream | null = null;
    async function startCamera() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch (err) {
        console.error("Camera failed", err);
      }
    }
    startCamera();
    return () => stream?.getTracks().forEach(track => track.stop());
  }, []);

  useEffect(() => {
    const loadContent = async () => {
      let currentContentId = "";
      let targetToLoad: UserTarget | null = null;

      if (receivedRange) {
        currentContentId = `manual-${receivedRange.surahName}-${receivedRange.from}-${receivedRange.to}`;
      } else {
        if (isGroup && activeParticipantId) {
          targetToLoad = groupTargets[activeParticipantId] || null;
        } else if (!isGroup) {
          targetToLoad = currentTarget;
        }
        
        if (targetToLoad) {
          currentContentId = `target-${targetToLoad.surahNomor}-${targetToLoad.from}-${targetToLoad.to}-${activeParticipantId || 'solo'}`;
        }
      }

      if (currentContentId === lastTargetIdRef.current) return;
      
      if (receivedRange) {
        setLocalRange(receivedRange);
        setActiveVerseIndex(0);
        lastTargetIdRef.current = currentContentId;
      } else if (targetToLoad) {
        setLoadingTarget(true);
        try {
          const allVerses = await apiService.getVerses(targetToLoad.surahNomor);
          const filtered = allVerses.filter(v => v.nomorAyat >= targetToLoad!.from && v.nomorAyat <= targetToLoad!.to);
          
          if (filtered.length > 0) {
            setLocalRange({
              from: targetToLoad.from,
              to: targetToLoad.to,
              verses: filtered,
              surahName: targetToLoad.surahName
            });
            setActiveVerseIndex(0);
            lastTargetIdRef.current = currentContentId;
          }
        } catch (err) {
          console.error("Gagal memuat target", err);
        } finally {
          setTimeout(() => setLoadingTarget(false), 300);
        }
      } else {
        setLocalRange(undefined);
        lastTargetIdRef.current = "";
      }
    };

    loadContent();
  }, [receivedRange, activeParticipantId, isGroup, currentTarget, groupTargets]);

  const showOverlay = !!(localRange || loadingTarget);
  
  // Logika tampilan ayat: 
  // Jika Tahfidz dan bukan Ustadz, ayat hanya tampil jika Ustadz mengizinkan (simulasi)
  const shouldHideAyatContent = mode === 'tahfidz' && !isUstadz && !isAyatVisibleForParticipant;

  const handleNextVerse = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (localRange && activeVerseIndex < localRange.verses.length - 1) {
      setActiveVerseIndex(prev => prev + 1);
    }
  };

  const handlePrevVerse = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (localRange && activeVerseIndex > 0) {
      setActiveVerseIndex(prev => prev - 1);
    }
  };

  return (
    <div className="fixed inset-0 bg-black z-[200] flex flex-col overflow-hidden font-sans animate-in fade-in duration-500">
      
      {/* HEADER: Mode Switcher - Hanya Ustadz yang bisa ganti mode di sistem asli, di sini kita izinkan demo */}
      <div className="absolute top-6 left-0 right-0 z-[110] flex justify-center pointer-events-none">
        <div className="bg-black/60 backdrop-blur-3xl p-1.5 rounded-full border border-white/10 flex gap-1 shadow-2xl pointer-events-auto">
          <button 
            onClick={() => setMode('tahsin')} 
            className={`px-6 py-2.5 rounded-full text-[9px] font-black uppercase transition-all ${mode === 'tahsin' ? 'bg-white text-black shadow-lg' : 'text-white/40'}`}
          >
            Tahsin
          </button>
          <button 
            onClick={() => {
              setMode('tahfidz');
              // Default sembunyikan ayat untuk peserta saat masuk mode tahfidz
              if (isUstadz) setIsAyatVisibleForParticipant(false);
            }} 
            className={`px-6 py-2.5 rounded-full text-[9px] font-black uppercase transition-all ${mode === 'tahfidz' ? 'bg-orange-600 text-white shadow-lg' : 'text-white/40'}`}
          >
            Tahfidz
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col h-full relative">
        
        {/* UPPER PART: Video Section */}
        <div className={`relative transition-all duration-700 ease-in-out overflow-hidden flex flex-col md:flex-row ${showOverlay ? 'h-[45%]' : 'h-full'}`}>
          <div className="flex-1 relative h-full grid grid-cols-1 md:grid-cols-2 gap-0.5 p-0.5 bg-neutral-900">
            <div className="relative bg-black rounded-xl overflow-hidden group">
               <img 
                 src={`https://picsum.photos/seed/${activeParticipantId || contactName}1/1200/800`} 
                 className={`w-full h-full object-cover transition-opacity duration-700 ${showOverlay ? 'opacity-40' : 'opacity-80'}`} 
                 alt="Video" 
               />
               <div className="absolute top-4 left-4 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                 <span className="text-white text-[9px] font-black uppercase tracking-widest flex items-center gap-2">
                   {isGroup && <Users className="w-3 h-3 text-emerald-400" />}
                   {activeParticipantId ? participants.find(p => p.id === activeParticipantId)?.name : contactName}
                   {!isUstadz && mode === 'tahfidz' && (
                     <span className="ml-2 px-2 py-0.5 bg-orange-600 rounded-md text-[8px]">Mode Setoran</span>
                   )}
                 </span>
               </div>
            </div>
            
            <div className={`hidden md:block relative bg-black rounded-xl overflow-hidden ${!showOverlay && 'md:hidden'}`}>
               <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover scale-x-[-1] opacity-60" />
            </div>
          </div>

          <div className={`absolute top-20 right-4 w-24 h-32 md:w-44 md:h-60 bg-black rounded-2xl overflow-hidden border border-white/10 shadow-2xl z-[80] transition-opacity duration-500 ${!videoOn && 'opacity-0'}`}>
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover scale-x-[-1]" />
            <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/60 backdrop-blur-md rounded-full border border-white/5 text-[7px] font-black text-white uppercase">Anda</div>
          </div>
        </div>

        {/* LOWER PART: Verse Section */}
        <div className={`bg-neutral-950 transition-all duration-700 ease-in-out border-t border-white/10 relative z-40 flex flex-col ${showOverlay ? 'h-[55%]' : 'h-0 overflow-hidden opacity-0 translate-y-full'}`}>
           {loadingTarget ? (
             <div className="flex-1 flex flex-col items-center justify-center gap-4">
               <Loader2 className="w-10 h-10 text-emerald-500 animate-spin" />
               <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.4em] animate-pulse">Menghimpun Hafalan...</p>
             </div>
           ) : localRange ? (
             <div className="flex-1 flex flex-col h-full overflow-hidden">
               {/* Info Header */}
               <div className="px-6 py-4 flex items-center justify-between border-b border-white/5 bg-white/5 shrink-0">
                 <div className="flex items-center gap-3">
                   <Target className="w-4 h-4 text-emerald-500" />
                   <p className="text-white font-black text-xs md:text-sm truncate">
                     {localRange.surahName}: Ayat {localRange.verses[activeVerseIndex].nomorAyat}
                   </p>
                 </div>
                 <div className="flex gap-1">
                   {localRange.verses.map((_, i) => (
                     <div key={i} className={`h-1 rounded-full transition-all duration-300 ${i === activeVerseIndex ? 'w-4 bg-emerald-500' : 'w-1 bg-white/10'}`} />
                   ))}
                 </div>
               </div>

               {/* Arabic Text Display */}
               <div className="flex-1 flex flex-col items-center justify-start px-6 md:px-12 overflow-y-auto custom-scrollbar bg-neutral-900/50 pt-6">
                 {shouldHideAyatContent ? (
                   <div className="flex-1 flex flex-col items-center justify-center text-center gap-4 animate-in fade-in">
                     <EyeOff className="w-12 h-12 text-white/10" />
                     <p className="text-[11px] font-black text-white/20 uppercase tracking-[0.3em]">Tampilan Ayat<br/>Disembunyikan Ustadz</p>
                     <p className="text-[9px] text-orange-500/60 font-bold italic">"Fokus pada hafalan Anda..."</p>
                   </div>
                 ) : (
                   <p className="font-arabic text-2xl sm:text-3xl md:text-4xl text-white text-center leading-[1.8] md:leading-[2.2] drop-shadow-2xl pb-16 transition-all duration-500">
                     {localRange.verses[activeVerseIndex].teksArab}
                   </p>
                 )}
               </div>

               {/* Verse Navigation */}
               <div className="flex justify-between items-center px-10 py-4 shrink-0 border-t border-white/5 bg-black/40">
                  <button 
                    onClick={handlePrevVerse} 
                    disabled={activeVerseIndex === 0} 
                    className="w-12 h-12 flex items-center justify-center bg-white/5 rounded-2xl text-white disabled:opacity-5 active:bg-emerald-500 transition-colors border border-white/10"
                  >
                    <ChevronLeft className="w-8 h-8" />
                  </button>
                  <p className="text-lg text-white font-black tracking-tighter">
                    {activeVerseIndex + 1} <span className="text-white/20 mx-1">/</span> {localRange.verses.length}
                  </p>
                  <button 
                    onClick={handleNextVerse} 
                    disabled={activeVerseIndex === localRange.verses.length - 1} 
                    className="w-12 h-12 flex items-center justify-center bg-white/5 rounded-2xl text-white disabled:opacity-5 active:bg-emerald-500 transition-colors border border-white/10"
                  >
                    <ChevronRight className="w-8 h-8" />
                  </button>
               </div>

               {/* Control Bar Spacer */}
               <div className="h-24 md:h-32 shrink-0" />
             </div>
           ) : (
             <div className="flex-1 flex flex-col items-center justify-center gap-2 opacity-30">
                <Book className="w-12 h-12 text-white" />
                <p className="text-[10px] text-white font-black uppercase tracking-widest">Pilih materi untuk dibahas</p>
             </div>
           )}
        </div>

        {/* BOTTOM PART: Sticky Control Bar */}
        <div className="absolute bottom-0 left-0 right-0 z-[100] h-24 md:h-32 bg-black/80 backdrop-blur-3xl border-t border-white/10 flex items-center justify-center">
          <div className="flex items-center gap-3 md:gap-8">
            {isGroup && isUstadz && (
              <button 
                onClick={() => {
                  if (participants.length === 0) return;
                  const currentIndex = participants.findIndex(p => p.id === activeParticipantId);
                  const nextIndex = (currentIndex + 1) % participants.length;
                  setActiveParticipantId(participants[nextIndex].id);
                }}
                className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-500 border border-emerald-500/30 flex items-center justify-center active:scale-90 transition-all"
                title="Ganti Peserta"
              >
                <Users className="w-6 h-6" />
              </button>
            )}

            {/* Tombol Mute Tampilan Ayat (Hanya Ustadz & Mode Tahfidz) */}
            {isUstadz && mode === 'tahfidz' && showOverlay && (
               <button 
                onClick={() => setIsAyatVisibleForParticipant(!isAyatVisibleForParticipant)}
                className={`w-12 h-12 md:w-16 md:h-16 rounded-2xl flex items-center justify-center transition-all border ${isAyatVisibleForParticipant ? 'bg-white/5 border-white/10 text-white' : 'bg-orange-600 border-orange-400 text-white shadow-lg'}`}
                title={isAyatVisibleForParticipant ? "Sembunyikan Ayat dari Peserta" : "Tampilkan Ayat ke Peserta"}
              >
                {isAyatVisibleForParticipant ? <Eye className="w-6 h-6 md:w-7 md:h-7" /> : <EyeOff className="w-6 h-6 md:w-7 md:h-7" />}
              </button>
            )}

            {/* Logika Tombol Book: 
                - Tahfidz: Hanya Ustadz yang bisa pilih ayat.
                - Tahsin: Keduanya bisa pilih ayat. */}
            {(mode === 'tahsin' || (mode === 'tahfidz' && isUstadz)) && (
              <button 
                onClick={onOpenVerseSelector}
                className="w-12 h-12 md:w-16 md:h-16 rounded-2xl bg-yellow-400 flex items-center justify-center hover:scale-110 active:scale-90 transition-all shadow-xl"
              >
                <Book className="w-6 h-6 md:w-8 md:h-8 text-black" />
              </button>
            )}

            <button 
              onClick={() => setMicOn(!micOn)}
              className={`w-12 h-12 md:w-16 md:h-16 rounded-full flex items-center justify-center border-2 transition-all ${micOn ? 'bg-white/5 border-white/10 text-white' : 'bg-red-600 border-red-400 text-white shadow-lg'}`}
            >
              {micOn ? <Mic className="w-6 h-6 md:w-7 md:h-7" /> : <VolumeX className="w-6 h-6 md:w-7 md:h-7" />}
            </button>

            <button 
              onClick={onEndCall}
              className="w-16 h-16 md:w-24 md:h-24 rounded-[2.2rem] bg-red-600 flex items-center justify-center hover:scale-110 active:scale-90 transition-all shadow-2xl border-4 border-red-500/20"
            >
              <PhoneOff className="w-8 h-8 md:w-12 md:h-12 text-white" />
            </button>

            <button 
              onClick={() => setVideoOn(!videoOn)}
              className={`w-12 h-12 md:w-16 md:h-16 rounded-full flex items-center justify-center border-2 transition-all ${videoOn ? 'bg-white/5 border-white/10 text-white' : 'bg-red-600 border-red-400 text-white shadow-lg'}`}
            >
              <Video className="w-6 h-6 md:w-7 md:h-7" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
