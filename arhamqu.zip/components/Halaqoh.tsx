
import React, { useState, useEffect, useRef } from 'react';
import { Send, Phone, MoreVertical, Video, Book, Plus, Users, X, Search, UserPlus, Users2, Check, User, Trophy, Target, ClipboardCheck, ChevronRight, Flag, ChevronDown, MessageSquare, History, CircleDashed, Camera, Image as ImageIcon, Pencil, ArrowLeft } from 'lucide-react';
import { CONTACTS, SURAH_LIST } from '../constants';
import { Contact, Message, Verse, VerseRange, ProgressRecord, Grade, Surah, UserTarget, UserStatus } from '../types';
import { chatAsTeacher } from '../services/geminiService';
import { apiService } from '../services/apiService';
import { VerseSelector } from './VerseSelector';
import { VideoCall } from './VideoCall';
import { ProgressDashboard } from './ProgressDashboard';
import { ArhamQuLogo } from '../App';

type SidebarView = 'CHATS' | 'STATUS' | 'PROFILE';
type InfoView = 'GROUP_INFO' | 'CONTACT_INFO' | null;

export const Halaqoh: React.FC = () => {
  const [activeSidebarView, setActiveSidebarView] = useState<SidebarView>('CHATS');
  const [activeInfoView, setActiveInfoView] = useState<InfoView>(null);
  
  // User Profile State
  const [userProfile, setUserProfile] = useState(() => {
    const saved = localStorage.getItem('halaqoh_user_profile');
    return saved ? JSON.parse(saved) : {
      name: 'Hamba Allah',
      about: 'Sedang belajar Al-Quran',
      avatar: 'https://picsum.photos/seed/me/200'
    };
  });

  const [contacts, setContacts] = useState<Contact[]>(() => {
    const saved = localStorage.getItem('halaqoh_contacts');
    return saved ? JSON.parse(saved) : CONTACTS;
  });
  
  const [statuses, setStatuses] = useState<UserStatus[]>(() => {
    return [
      { id: 's1', userId: '1', userName: 'Ustadz Ahmad', userAvatar: 'https://picsum.photos/seed/ustadz1/200', imageUrl: 'https://picsum.photos/seed/status1/800/1200', caption: 'Semangat setoran pagi ini!', timestamp: new Date(), isRead: false },
      { id: 's2', userId: '3', userName: 'Ustadzah Fatimah', userAvatar: 'https://picsum.photos/seed/ustadz2/200', imageUrl: 'https://picsum.photos/seed/status2/800/1200', caption: 'Jadwal bimbingan baru sudah rilis.', timestamp: new Date(), isRead: false }
    ];
  });

  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [messages, setMessages] = useState<Record<string, Message[]>>({});
  const [input, setInput] = useState('');
  const [showVerseSelector, setShowVerseSelector] = useState(false);
  const [isCalling, setIsCalling] = useState(false);
  const [activeCallRange, setActiveCallRange] = useState<VerseRange | undefined>();
  const [searchContact, setSearchContact] = useState('');
  
  const [showMenu, setShowMenu] = useState(false);
  const [showProgress, setShowProgress] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [activeStatus, setActiveStatus] = useState<UserStatus | null>(null);

  // Profile Edit States
  const [isEditingName, setIsEditingName] = useState(false);
  const [isEditingAbout, setIsEditingAbout] = useState(false);
  const [tempProfileName, setTempProfileName] = useState(userProfile.name);
  const [tempProfileAbout, setTempProfileAbout] = useState(userProfile.about);

  // Group Edit States
  const [isEditingGroupName, setIsEditingGroupName] = useState(false);
  const [tempGroupName, setTempGroupName] = useState('');

  // Form states for adding new
  const [newContactName, setNewContactName] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newGroupName, setNewGroupName] = useState('');
  const [selectedGroupMembers, setSelectedGroupMembers] = useState<string[]>([]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem('halaqoh_contacts', JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem('halaqoh_user_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, selectedContact]);

  const handleSend = async (text: string, range?: VerseRange) => {
    if (!selectedContact || (!text.trim() && !range)) return;
    const contactId = selectedContact.id;
    const newMessage: Message = { id: Date.now().toString(), sender: 'me', senderName: 'Saya', text, verseRange: range, timestamp: new Date() };
    setMessages(prev => ({ ...prev, [contactId]: [...(prev[contactId] || []), newMessage] }));
    setInput('');
    if (range) {
      if (isCalling) {
        setActiveCallRange(range);
      }
      
      setTimeout(() => {
        const resp: Message = { id: Date.now().toString(), sender: 'teacher', senderName: selectedContact.name, text: `Maa syaa Allah. Silahkan mulai setoran.`, timestamp: new Date() };
        setMessages(prev => ({ ...prev, [contactId]: [...(prev[contactId] || []), resp] }));
      }, 800);
    } else {
      const response = await chatAsTeacher(text, []);
      setTimeout(() => {
        const resp: Message = { id: Date.now().toString(), sender: 'teacher', senderName: selectedContact.name, text: response, timestamp: new Date() };
        setMessages(prev => ({ ...prev, [contactId]: [...(prev[contactId] || []), resp] }));
      }, 500);
    }
  };

  const handleSaveUserProfile = () => {
    setUserProfile({ ...userProfile, name: tempProfileName, about: tempProfileAbout });
    setIsEditingName(false);
    setIsEditingAbout(false);
  };

  const handleUpdateGroupProfile = () => {
    if (!selectedContact || !tempGroupName.trim()) return;
    const updatedContacts = contacts.map(c => 
      c.id === selectedContact.id ? { ...c, name: tempGroupName } : c
    );
    setContacts(updatedContacts);
    setSelectedContact({ ...selectedContact, name: tempGroupName });
    setIsEditingGroupName(false);
  };

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName) return;
    const newC: Contact = {
      id: Date.now().toString(),
      name: newContactName,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(newContactName)}&background=075e54&color=fff`,
      lastMessage: 'Baru saja ditambahkan',
      status: 'offline'
    };
    setContacts(prev => [newC, ...prev]);
    setShowAddContact(false);
    setNewContactName('');
    setNewContactPhone('');
  };

  const handleCreateGroup = () => {
    if (!newGroupName || selectedGroupMembers.length === 0) return;
    const newG: Contact = {
      id: 'g' + Date.now(),
      name: newGroupName,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(newGroupName)}&background=128c7e&color=fff`,
      lastMessage: 'Grup bimbingan baru dibuat',
      status: 'online',
      isGroup: true,
      members: selectedGroupMembers
    };
    setContacts(prev => [newG, ...prev]);
    setShowCreateGroup(false);
    setNewGroupName('');
    setSelectedGroupMembers([]);
  };

  const toggleGroupMember = (id: string) => {
    setSelectedGroupMembers(prev => prev.includes(id) ? prev.filter(m => m !== id) : [...prev, id]);
  };

  const filteredContacts = contacts.filter(c => c.name.toLowerCase().includes(searchContact.toLowerCase()));

  return (
    <div className="flex h-full bg-[#f0f2f5] relative overflow-hidden font-sans">
      
      {/* SIDEBAR */}
      <div className={`w-full md:w-[410px] flex flex-col bg-white border-r border-gray-200 transition-all duration-300 relative ${selectedContact ? 'hidden md:flex' : 'flex'}`}>
        
        {/* Personal Profile View */}
        <div className={`absolute inset-0 z-[120] bg-[#f0f2f5] transition-transform duration-300 flex flex-col ${activeSidebarView === 'PROFILE' ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="bg-[#075e54] h-[108px] p-6 flex items-end">
            <div className="flex items-center gap-6 text-white">
              <button onClick={() => setActiveSidebarView('CHATS')} className="hover:opacity-70"><ArrowLeft className="w-6 h-6" /></button>
              <h3 className="font-bold text-lg">Profil</h3>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            <div className="py-8 flex justify-center bg-white mb-6 shadow-sm">
              <div className="relative group cursor-pointer">
                <img src={userProfile.avatar} className="w-48 h-48 rounded-full object-cover" />
                <div className="absolute inset-0 bg-black/40 rounded-full flex flex-col items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                   <Camera className="w-8 h-8 mb-1" />
                   <span className="text-[10px] font-bold uppercase">Ubah Foto</span>
                </div>
              </div>
            </div>

            <div className="bg-white px-8 py-4 mb-4 shadow-sm">
              <p className="text-[#008069] text-sm font-medium mb-4">Nama Anda</p>
              <div className="flex items-center justify-between">
                {isEditingName ? (
                  <input 
                    type="text" 
                    className="flex-1 bg-transparent border-b-2 border-[#008069] outline-none py-1 text-gray-800"
                    value={tempProfileName}
                    onChange={(e) => setTempProfileName(e.target.value)}
                    autoFocus
                    onBlur={handleSaveUserProfile}
                    onKeyPress={(e) => e.key === 'Enter' && handleSaveUserProfile()}
                  />
                ) : (
                  <span className="text-gray-800 text-lg">{userProfile.name}</span>
                )}
                {!isEditingName && <button onClick={() => setIsEditingName(true)} className="text-gray-400"><Pencil className="w-5 h-5" /></button>}
                {isEditingName && <button onClick={handleSaveUserProfile} className="text-[#008069]"><Check className="w-6 h-6" /></button>}
              </div>
              <p className="text-xs text-gray-500 mt-4 leading-relaxed">
                Ini bukan nama pengguna atau PIN Anda. Nama ini akan terlihat oleh kontak Halaqoh Anda.
              </p>
            </div>

            <div className="bg-white px-8 py-4 shadow-sm">
              <p className="text-[#008069] text-sm font-medium mb-4">Info</p>
              <div className="flex items-center justify-between">
                 {isEditingAbout ? (
                   <input 
                     type="text" 
                     className="flex-1 bg-transparent border-b-2 border-[#008069] outline-none py-1 text-gray-800"
                     value={tempProfileAbout}
                     onChange={(e) => setTempProfileAbout(e.target.value)}
                     autoFocus
                     onBlur={handleSaveUserProfile}
                     onKeyPress={(e) => e.key === 'Enter' && handleSaveUserProfile()}
                   />
                 ) : (
                   <span className="text-gray-800">{userProfile.about}</span>
                 )}
                 {!isEditingAbout && <button onClick={() => setIsEditingAbout(true)} className="text-gray-400"><Pencil className="w-5 h-5" /></button>}
                 {isEditingAbout && <button onClick={handleSaveUserProfile} className="text-[#008069]"><Check className="w-6 h-6" /></button>}
              </div>
            </div>
          </div>
        </div>

        {/* Header Sidebar */}
        <div className="bg-[#075e54] p-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-full overflow-hidden bg-white/20 border border-white/10 cursor-pointer" onClick={() => setActiveSidebarView('PROFILE')}>
               <img src={userProfile.avatar} className="w-full h-full object-cover" />
             </div>
             <h2 className="text-white font-bold text-lg">Halaqoh</h2>
          </div>
          <div className="flex items-center gap-5 text-white/80">
            <CircleDashed 
              className={`w-6 h-6 cursor-pointer hover:text-white transition-colors ${activeSidebarView === 'STATUS' ? 'text-white' : ''}`} 
              onClick={() => setActiveSidebarView(activeSidebarView === 'STATUS' ? 'CHATS' : 'STATUS')}
              title="Status" 
            />
            <div className="relative">
              <Plus className="w-6 h-6 cursor-pointer hover:text-white transition-colors" onClick={() => setShowMenu(!showMenu)} />
              {showMenu && (
                <div className="absolute right-0 mt-3 w-56 bg-white rounded-xl shadow-2xl border border-gray-100 z-[100] py-2 overflow-hidden text-gray-800">
                  <button onClick={() => { setShowAddContact(true); setShowMenu(false); }} className="w-full px-6 py-3 text-sm font-medium hover:bg-gray-50 flex items-center gap-3">
                    <UserPlus className="w-4 h-4 text-[#075e54]" /> Kontak Baru
                  </button>
                  <button onClick={() => { setShowCreateGroup(true); setShowMenu(false); }} className="w-full px-6 py-3 text-sm font-medium hover:bg-gray-50 flex items-center gap-3">
                    <Users2 className="w-4 h-4 text-[#075e54]" /> Grup Baru
                  </button>
                  <div className="border-t border-gray-100 my-1"></div>
                  <button onClick={() => { setShowProgress(true); setShowMenu(false); }} className="w-full px-6 py-3 text-sm font-medium hover:bg-gray-50 flex items-center gap-3">
                    <History className="w-4 h-4 text-[#075e54]" /> Riwayat Progres
                  </button>
                </div>
              )}
            </div>
            < MoreVertical className="w-6 h-6 cursor-pointer hover:text-white" />
          </div>
        </div>

        {activeSidebarView === 'CHATS' ? (
          <>
            <div className="px-3 py-2 bg-white">
              <div className="relative bg-[#f0f2f5] rounded-xl flex items-center px-4 py-1.5">
                <Search className="w-4 h-4 text-gray-500" />
                <input 
                  type="text" 
                  placeholder="Cari chat bimbingan" 
                  className="bg-transparent border-none outline-none w-full ml-4 text-sm font-medium text-gray-700"
                  value={searchContact}
                  onChange={(e) => setSearchContact(e.target.value)}
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar">
              {filteredContacts.map(c => (
                <button 
                  key={c.id} 
                  onClick={() => setSelectedContact(c)} 
                  className={`w-full flex items-center px-4 py-3 border-b border-gray-50 transition-colors ${selectedContact?.id === c.id ? 'bg-[#f0f2f5]' : 'hover:bg-gray-50'}`}
                >
                  <div className="relative shrink-0">
                    <img src={c.avatar} className="w-12 h-12 rounded-full border border-gray-200 object-cover" alt={c.name} />
                    {c.status === 'online' && <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" />}
                  </div>
                  <div className="ml-4 flex-1 text-left overflow-hidden">
                    <div className="flex justify-between items-center mb-0.5">
                      <h3 className="font-bold text-[15px] text-gray-800 truncate">{c.name}</h3>
                      <span className="text-[11px] text-gray-400 font-medium">10:45</span>
                    </div>
                    <p className="text-[13px] text-gray-500 truncate">{c.lastMessage}</p>
                  </div>
                </button>
              ))}
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col bg-[#f0f2f5] overflow-y-auto custom-scrollbar">
            <div className="bg-white p-4 flex items-center gap-4 cursor-pointer mb-2">
               <div className="relative">
                 <img src={userProfile.avatar} className="w-12 h-12 rounded-full" />
                 <div className="absolute bottom-0 right-0 bg-emerald-500 rounded-full p-0.5 border-2 border-white">
                   <Plus className="w-3 h-3 text-white" />
                 </div>
               </div>
               <div className="flex-1">
                 <h4 className="font-bold text-gray-800">Status Saya</h4>
                 <p className="text-xs text-gray-500">Ketuk untuk menambah status</p>
               </div>
            </div>
            <div className="px-4 py-2"><h5 className="text-[13px] font-bold text-[#075e54] uppercase tracking-wider mb-2">Pembaruan terkini</h5></div>
            <div className="bg-white">
              {statuses.map(s => (
                <button key={s.id} onClick={() => setActiveStatus(s)} className="w-full flex items-center gap-4 p-4 border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <div className="p-[2px] rounded-full border-2 border-emerald-500"><img src={s.userAvatar} className="w-12 h-12 rounded-full border-2 border-white" /></div>
                  <div className="flex-1 text-left"><h4 className="font-bold text-gray-800">{s.userName}</h4></div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* MAIN CHAT AREA */}
      <div className={`flex-1 flex relative bg-[#e5ddd5] ${!selectedContact && 'hidden md:flex'}`}>
        <div className="absolute inset-0 opacity-[0.06] pointer-events-none" style={{ backgroundImage: 'url("https://www.transparenttextures.com/patterns/cubes.png")' }} />

        {selectedContact ? (
          <div className="flex flex-1 flex-col h-full relative">
            <div className="h-[60px] bg-[#f0f2f5] px-4 flex items-center justify-between border-b border-gray-200 z-10 shrink-0">
              <div className="flex items-center flex-1 cursor-pointer" onClick={() => setActiveInfoView(selectedContact.isGroup ? 'GROUP_INFO' : 'CONTACT_INFO')}>
                <button onClick={(e) => { e.stopPropagation(); setSelectedContact(null); }} className="md:hidden mr-3 p-1 text-gray-500"><ChevronRight className="w-6 h-6 rotate-180" /></button>
                <img src={selectedContact.avatar} className="w-10 h-10 rounded-full mr-3" />
                <div className="flex-1 overflow-hidden">
                  <h3 className="font-bold text-[14px] text-gray-800 truncate">{selectedContact.name}</h3>
                  <p className="text-[11px] text-emerald-600 font-medium tracking-tight">online</p>
                </div>
              </div>
              <div className="flex items-center gap-6 text-gray-500">
                <Video onClick={() => setIsCalling(true)} className="w-5 h-5 cursor-pointer hover:text-[#075e54]" />
                <Phone className="w-5 h-5 cursor-pointer hover:text-[#075e54]" />
                <MoreVertical className="w-5 h-5 cursor-pointer" />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 md:px-12 space-y-2 custom-scrollbar z-0 relative">
              {(messages[selectedContact.id] || []).map(msg => (
                <div key={msg.id} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`relative max-w-[85%] px-3 py-1.5 rounded-lg shadow-sm text-[14px] ${msg.sender === 'me' ? 'bg-[#dcf8c6] text-gray-800 rounded-tr-none' : 'bg-white text-gray-800 rounded-tl-none'}`}>
                    {msg.verseRange && (
                       <div className="mb-2 p-3 bg-black/5 rounded-md border-l-4 border-emerald-500 space-y-3">
                         <p className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">{msg.verseRange.surahName}</p>
                         <div className="space-y-3">
                           {msg.verseRange.verses.map((v, i) => (
                             <div key={i} className="flex flex-col gap-1.5">
                                <div className="flex justify-between items-start gap-3">
                                  <span className="shrink-0 text-[8px] font-black text-emerald-700 bg-emerald-100/50 w-5 h-5 flex items-center justify-center rounded-full border border-emerald-200">{v.nomorAyat}</span>
                                  <p className="font-arabic text-base text-right leading-[1.8] md:leading-[2.2] flex-1 text-gray-900">{v.teksArab}</p>
                                </div>
                                <p className="text-[10px] text-gray-500 italic leading-snug pl-8">{v.teksLatin}</p>
                             </div>
                           ))}
                         </div>
                       </div>
                    )}
                    <div className="flex items-end gap-2">
                      <p className="leading-relaxed">{msg.text}</p>
                      <span className="text-[9px] text-gray-400 font-bold uppercase pt-2">
                        {msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        {msg.sender === 'me' && <Check className="w-3 h-3 text-blue-500 inline ml-1" />}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            <div className="bg-[#f0f2f5] p-2 flex items-center gap-2 z-10 border-t border-gray-200 shrink-0">
              <button onClick={() => setShowVerseSelector(true)} className="p-2 text-gray-500" title="Al-Quran"><Book className="w-6 h-6" /></button>
              <input 
                type="text" 
                placeholder="Ketik pesan bimbingan..." 
                className="flex-1 bg-white px-4 py-2.5 rounded-xl outline-none text-sm font-medium"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && handleSend(input)}
              />
              <button onClick={() => handleSend(input)} className={`p-3 rounded-full transition-all ${input.trim() ? 'bg-[#075e54] text-white' : 'bg-gray-400 text-white opacity-50'}`}>
                <Send className="w-5 h-5" />
              </button>
            </div>

            {/* INFO VIEW OVERLAY */}
            <div className={`absolute top-0 right-0 bottom-0 w-full md:w-[410px] bg-[#f0f2f5] z-50 transition-transform duration-300 shadow-2xl flex flex-col ${activeInfoView ? 'translate-x-0' : 'translate-x-full'}`}>
              <div className="h-[60px] bg-white px-4 flex items-center gap-6 border-b border-gray-200 shrink-0">
                <button onClick={() => { setActiveInfoView(null); setIsEditingGroupName(false); }} className="text-gray-500 hover:text-black"><X className="w-6 h-6" /></button>
                <h3 className="font-bold text-gray-800">{selectedContact.isGroup ? 'Info Grup' : 'Info Kontak'}</h3>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar">
                <div className="bg-white py-8 flex flex-col items-center mb-4 shadow-sm">
                   <div className="relative group mb-4">
                      <img src={selectedContact.avatar} className="w-48 h-48 rounded-full object-cover" />
                      {selectedContact.isGroup && (
                        <div className="absolute inset-0 bg-black/40 rounded-full flex flex-col items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                           <Camera className="w-8 h-8 mb-1" />
                           <span className="text-[10px] font-bold uppercase">Ubah Foto</span>
                        </div>
                      )}
                   </div>
                   <div className="w-full px-8 text-center">
                      <div className="flex items-center justify-center gap-3">
                         {isEditingGroupName && selectedContact.isGroup ? (
                            <input 
                              type="text" 
                              className="bg-transparent border-b-2 border-[#008069] outline-none py-1 text-gray-800 text-2xl font-bold text-center"
                              value={tempGroupName}
                              onChange={(e) => setTempGroupName(e.target.value)}
                              autoFocus
                              onBlur={handleUpdateGroupProfile}
                              onKeyPress={(e) => e.key === 'Enter' && handleUpdateGroupProfile()}
                            />
                         ) : (
                            <h2 className="text-2xl font-bold text-gray-800">{selectedContact.name}</h2>
                         )}
                         {selectedContact.isGroup && !isEditingGroupName && (
                           <button onClick={() => { setIsEditingGroupName(true); setTempGroupName(selectedContact.name); }} className="text-gray-400"><Pencil className="w-4 h-4" /></button>
                         )}
                      </div>
                      <p className="text-gray-500 mt-1">{selectedContact.isGroup ? `Grup · ${selectedContact.members?.length || 0} peserta` : '+62 812-3456-7890'}</p>
                   </div>
                </div>

                {selectedContact.isGroup && (
                  <div className="bg-white px-8 py-4 mb-4 shadow-sm">
                    <p className="text-[#008069] text-sm font-medium mb-2">Deskripsi Grup</p>
                    <p className="text-gray-800 text-sm italic">"Halaqoh digital bimbingan tahsin & tahfidz ArhamQu. Mari bersama menjaga Kalamullah."</p>
                  </div>
                )}

                {!selectedContact.isGroup && (
                  <div className="bg-white px-8 py-4 mb-4 shadow-sm">
                    <p className="text-[#008069] text-sm font-medium mb-2">Info</p>
                    <p className="text-gray-800 text-sm">Mari belajar bersama!</p>
                  </div>
                )}

                {selectedContact.isGroup && (
                  <div className="bg-white px-8 py-4 shadow-sm">
                    <p className="text-[#008069] text-sm font-medium mb-4">{selectedContact.members?.length || 0} Peserta</p>
                    <div className="space-y-4">
                       <button className="flex items-center gap-4 text-[#008069] font-medium w-full">
                          <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center"><UserPlus className="w-5 h-5" /></div>
                          <span>Tambah Peserta</span>
                       </button>
                       {selectedContact.members?.map(mId => {
                         const m = contacts.find(c => c.id === mId);
                         return m ? (
                           <div key={mId} className="flex items-center gap-4">
                              <img src={m.avatar} className="w-10 h-10 rounded-full" />
                              <div className="flex-1">
                                <p className="font-bold text-gray-800 text-sm">{m.name}</p>
                                <p className="text-xs text-gray-500">Murojaah Juz 30</p>
                              </div>
                           </div>
                         ) : null;
                       })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-10 text-center text-gray-400">
             <div className="w-48 h-48 opacity-[0.05] grayscale mb-8"><ArhamQuLogo className="w-full h-full" /></div>
             <h2 className="text-3xl font-black text-gray-300">WhatsApp Halaqoh</h2>
             <p className="mt-4 max-w-sm text-sm">Pilih kontak atau grup untuk memulai bimbingan tahsin & tahfidz Al-Quran.</p>
          </div>
        )}
      </div>

      {/* VIDEO CALL OVERLAY */}
      {isCalling && selectedContact && (
        <VideoCall 
          contactName={selectedContact.name}
          onEndCall={() => { setIsCalling(false); setActiveCallRange(undefined); }}
          onOpenVerseSelector={() => setShowVerseSelector(true)}
          receivedRange={activeCallRange}
          // Logika Role: Deteksi apakah nama kontak mengandung 'Ustadz' atau profil kita adalah Ustadz
          isUstadz={selectedContact.name.includes('Ustadz') || userProfile.name.includes('Ustadz')} 
          isGroup={selectedContact.isGroup}
          participants={selectedContact.isGroup ? contacts.filter(c => selectedContact.members?.includes(c.id)) : []}
          groupTargets={selectedContact.memberTargets}
          currentTarget={selectedContact.currentTarget}
        />
      )}

      {/* FULL-SCREEN OVERLAYS */}
      {showProgress && <div className="absolute inset-0 z-[150] bg-white animate-in slide-in-from-right duration-500"><ProgressDashboard records={[]} onClose={() => setShowProgress(false)} /></div>}
      
      {/* STATUS VIEWER OVERLAY */}
      {activeStatus && (
        <div className="fixed inset-0 z-[600] bg-black flex flex-col items-center justify-center animate-in zoom-in duration-300">
          <div className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/60 to-transparent flex items-center justify-between">
            <div className="flex items-center gap-3">
               <img src={activeStatus.userAvatar} className="w-10 h-10 rounded-full border border-white" />
               <div className="text-white">
                 <h4 className="font-bold text-sm">{activeStatus.userName}</h4>
                 <p className="text-[10px] opacity-70">Baru saja</p>
               </div>
            </div>
            <button onClick={() => setActiveStatus(null)} className="p-2 text-white"><X className="w-8 h-8" /></button>
          </div>
          <div className="w-full h-full max-w-lg bg-neutral-900 relative">
            <img src={activeStatus.imageUrl} className="w-full h-full object-contain" />
            <div className="absolute bottom-0 left-0 right-0 p-10 text-center bg-gradient-to-t from-black/80 to-transparent">
              <p className="text-white text-lg font-bold">{activeStatus.caption}</p>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Tambah Kontak */}
      {showAddContact && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-6 backdrop-blur-md bg-black/40 animate-in fade-in">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
            <div className="p-6 bg-[#075e54] text-white flex items-center justify-between">
              <h3 className="font-bold text-lg">Tambah Kontak Baru</h3>
              <button onClick={() => setShowAddContact(false)}><X className="w-6 h-6" /></button>
            </div>
            <form onSubmit={handleAddContact} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Nama Lengkap</label>
                <input type="text" className="w-full px-4 py-3 bg-gray-50 rounded-xl border-none outline-none focus:ring-2 focus:ring-[#075e54]" value={newContactName} onChange={(e) => setNewContactName(e.target.value)} required />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Nomor WhatsApp</label>
                <input type="tel" className="w-full px-4 py-3 bg-gray-50 rounded-xl border-none outline-none focus:ring-2 focus:ring-[#075e54]" value={newContactPhone} onChange={(e) => setNewContactPhone(e.target.value)} />
              </div>
              <button type="submit" className="w-full bg-[#075e54] text-white py-4 rounded-xl font-bold uppercase text-sm active:scale-95 transition-all">Simpan Kontak</button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Buat Grup */}
      {showCreateGroup && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-6 backdrop-blur-md bg-black/40 animate-in fade-in">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
            <div className="p-6 bg-[#075e54] text-white flex items-center justify-between">
              <h3 className="font-bold text-lg">Buat Grup Bimbingan</h3>
              <button onClick={() => setShowCreateGroup(false)}><X className="w-6 h-6" /></button>
            </div>
            <div className="p-6 overflow-y-auto flex-1 space-y-4 custom-scrollbar">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 uppercase">Nama Grup</label>
                <input type="text" className="w-full px-4 py-3 bg-gray-50 rounded-xl border-none outline-none focus:ring-2 focus:ring-[#075e54]" value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} required />
              </div>
              <div className="pt-4 border-t border-gray-100">
                <label className="text-xs font-bold text-gray-500 uppercase block mb-3">Pilih Peserta ({selectedGroupMembers.length})</label>
                {contacts.filter(c => !c.isGroup).map(c => (
                  <button key={c.id} onClick={() => toggleGroupMember(c.id)} className={`w-full flex items-center p-3 rounded-xl border-2 mb-2 transition-all ${selectedGroupMembers.includes(c.id) ? 'bg-emerald-50 border-emerald-500' : 'bg-white border-gray-50'}`}>
                    <img src={c.avatar} className="w-10 h-10 rounded-full mr-3" />
                    <p className="flex-1 text-left font-bold text-sm">{c.name}</p>
                    {selectedGroupMembers.includes(c.id) && <Check className="w-5 h-5 text-emerald-500" />}
                  </button>
                ))}
              </div>
            </div>
            <div className="p-6 border-t border-gray-100">
              <button onClick={handleCreateGroup} disabled={!newGroupName || selectedGroupMembers.length === 0} className="w-full bg-[#075e54] text-white py-4 rounded-xl font-bold uppercase text-sm disabled:opacity-50 active:scale-95 transition-all">Buat Grup</button>
            </div>
          </div>
        </div>
      )}

      {showVerseSelector && <VerseSelector onClose={() => setShowVerseSelector(false)} onSend={(range) => { handleSend("Materi Qurani:", range); setShowVerseSelector(false); }} />}
    </div>
  );
};
