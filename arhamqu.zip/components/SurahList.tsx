
import React, { useState, useEffect } from 'react';
import { Search, Loader2 } from 'lucide-react';
import { apiService } from '../services/apiService';
import { Surah } from '../types';

interface SurahListProps {
  onSelectSurah: (surah: Surah) => void;
}

export const SurahList: React.FC<SurahListProps> = ({ onSelectSurah }) => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const loadSurahs = async () => {
      const data = await apiService.getSurahs();
      setSurahs(data);
      setLoading(false);
    };
    loadSurahs();
  }, []);

  const filteredSurahs = surahs.filter(s => 
    s.namaLatin.toLowerCase().includes(search.toLowerCase()) || 
    s.nomor.toString().includes(search)
  );

  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-4 text-emerald-600 h-full">
        <Loader2 className="w-12 h-12 animate-spin" />
        <p className="font-bold text-sm tracking-widest animate-pulse">MEMUAT DAFTAR SURAH</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white md:bg-gray-50">
      <div className="p-4 md:p-8 bg-white md:border-b sticky top-0 z-10 shadow-sm">
        <div className="max-w-xl mx-auto relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 group-focus-within:text-emerald-500 transition-colors" />
          <input 
            type="text"
            placeholder="Cari Surah (contoh: Al-Baqarah atau 2)..."
            className="w-full pl-12 pr-4 py-3 md:py-4 bg-gray-100 md:bg-white rounded-2xl border-transparent md:border-gray-200 border-2 focus:border-emerald-500 focus:bg-white focus:outline-none transition-all shadow-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 md:p-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 max-w-7xl mx-auto">
          {filteredSurahs.map(surah => (
            <button
              key={surah.nomor}
              onClick={() => onSelectSurah(surah)}
              className="group bg-white flex items-center p-4 md:p-6 rounded-2xl border border-gray-100 hover:border-emerald-200 hover:shadow-xl hover:shadow-emerald-900/5 transition-all active:scale-[0.98] text-left"
            >
              <div className="w-12 h-12 bg-emerald-50 text-emerald-700 font-bold rounded-xl flex items-center justify-center mr-4 shrink-0 transform rotate-45 group-hover:rotate-[135deg] transition-transform duration-500 shadow-sm">
                <span className="transform -rotate-45 group-hover:-rotate-[135deg] transition-transform duration-500">{surah.nomor}</span>
              </div>
              <div className="flex-1 overflow-hidden">
                <h3 className="font-bold text-gray-800 uppercase tracking-tight truncate group-hover:text-emerald-700 transition-colors">{surah.namaLatin}</h3>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest truncate">{surah.arti}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="px-2 py-0.5 bg-gray-100 text-[10px] text-gray-500 rounded font-bold">{surah.tempatTurun}</span>
                  <span className="px-2 py-0.5 bg-emerald-50 text-[10px] text-emerald-600 rounded font-bold">{surah.jumlahAyat} Ayat</span>
                </div>
              </div>
              <div className="text-right ml-2">
                <p className="font-arabic text-3xl text-emerald-600 group-hover:scale-110 transition-transform origin-right">{surah.nama}</p>
              </div>
            </button>
          ))}
        </div>

        {filteredSurahs.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <Search className="w-16 h-16 mb-4 opacity-10" />
            <p className="font-medium">Surah tidak ditemukan</p>
          </div>
        )}
      </div>
    </div>
  );
};
