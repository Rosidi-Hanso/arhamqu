
import { GoogleGenAI } from "@google/genai";
import { Verse } from "../types";

// Always use the named parameter `apiKey` for initialization.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Gets a teacher-like explanation for a specific verse.
 */
export async function getVerseExplanation(verse: Verse, surahName: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Explain the meaning and wisdom of Surah ${surahName} verse ${verse.nomorAyat} in Indonesian: "${verse.teksArab}". Keep it concise like a teacher in a chat.`,
      config: {
        systemInstruction: "You are a wise and friendly Islamic teacher (Ustadz) helping students understand the Quran.",
        temperature: 0.7,
      },
    });
    // The `text` property directly returns the extracted string.
    return response.text || "Subhanallah, ayat ini mengandung makna yang sangat dalam. Mari kita pelajari lebih lanjut.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Maaf, Ustadz sedang tidak bisa memberikan penjelasan saat ini.";
  }
}

/**
 * Chats with Ustadz Ahmad using the Gemini API Chat session.
 */
export async function chatAsTeacher(userInput: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]): Promise<string> {
  try {
    // Correct way to initialize a chat session and send messages.
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: "You are Ustadz Ahmad, a mentor for a Quran learning group. You respond kindly and provide Islamic guidance. If asked about Quran verses, encourage the student. Answer in Indonesian.",
      }
    });
    
    // Use chat.sendMessage for text-based chat interactions.
    const response = await chat.sendMessage({ message: userInput });
    
    // Use .text property instead of calling .text().
    return response.text || "Assalamu'alaikum, ada yang bisa saya bantu?";
  } catch (error) {
    console.error("Chat Error:", error);
    return "Maaf, koneksi terputus.";
  }
}
