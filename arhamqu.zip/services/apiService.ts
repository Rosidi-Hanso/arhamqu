
import { Contact, Message, Verse, Surah } from '../types';
import { SURAH_LIST } from '../constants';

const QURAN_API_BASE = 'https://equran.id/api/v2';
const JUZ_API_BASE = 'https://api.quran.gading.dev';

export const apiService = {
  getSurahs: async (): Promise<Surah[]> => {
    try {
      const response = await fetch(`${QURAN_API_BASE}/surat`);
      const data = await response.json();
      return data.data.map((s: any) => ({
        nomor: s.nomor,
        nama: s.nama,
        namaLatin: s.namaLatin,
        jumlahAyat: s.jumlahAyat,
        tempatTurun: s.tempatTurun,
        arti: s.arti
      }));
    } catch (err) {
      console.error("Failed to fetch surahs", err);
      return [];
    }
  },

  getVerses: async (surahNumber: number): Promise<Verse[]> => {
    try {
      const response = await fetch(`${QURAN_API_BASE}/surat/${surahNumber}`);
      const data = await response.json();
      return data.data.ayat.map((a: any) => ({
        nomorAyat: a.nomorAyat,
        teksArab: a.teksArab,
        teksLatin: a.teksLatin,
        teksIndonesia: a.teksIndonesia
      }));
    } catch (err) {
      console.error("Failed to fetch verses", err);
      return [];
    }
  },

  getJuzDetail: async (juzNumber: number): Promise<any> => {
    try {
      const response = await fetch(`${JUZ_API_BASE}/juz/${juzNumber}`);
      const data = await response.json();
      return data.data;
    } catch (err) {
      console.error("Failed to fetch juz detail", err);
      return null;
    }
  },

  loginWithWhatsApp: async (phone: string) => {
    await new Promise(r => setTimeout(r, 1500));
    return { 
      status: 'success', 
      user: { 
        phone, 
        name: 'Hamba Allah',
        avatar: `https://ui-avatars.com/api/?name=${phone}&background=016c4c&color=fff`
      } 
    };
  },

  syncContacts: async () => {
    await new Promise(r => setTimeout(r, 2000));
    return true;
  },

  sendMessage: async (chatId: string, text: string, verse?: any) => {
    await new Promise(r => setTimeout(r, 200));
    return { id: Date.now().toString(), timestamp: new Date() };
  }
};
