
export enum AppTab {
  SURAH = 'surah',
  JUZ = 'juz',
  HALAQOH = 'halaqoh'
}

export interface Surah {
  nomor: number;
  nama: string;
  namaLatin: string;
  jumlahAyat: number;
  tempatTurun: string;
  arti: string;
}

export interface Verse {
  nomorAyat: number;
  teksArab: string;
  teksLatin: string;
  teksIndonesia: string;
}

export interface UserTarget {
  surahNomor: number;
  surahName: string;
  from: number;
  to: number;
}

export interface VerseRange {
  from: number;
  to: number;
  verses: Verse[];
  surahName: string;
}

export type LearningMode = 'tahsin' | 'tahfidz';
export type Grade = 'A' | 'B' | 'C' | 'D';

export interface ProgressRecord {
  id: string;
  date: string;
  type: LearningMode;
  surahName: string;
  verseRange: string;
  grade: Grade;
  note: string;
  targetNext: string;
  teacherName: string;
}

export interface Message {
  id: string;
  sender: 'me' | 'teacher' | string;
  senderName?: string;
  text: string;
  verseRange?: VerseRange;
  progressRecord?: ProgressRecord;
  timestamp: Date;
}

export interface UserStatus {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  imageUrl: string;
  caption: string;
  timestamp: Date;
  isRead: boolean;
}

export interface Contact {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  status: 'online' | 'offline';
  isGroup?: boolean;
  members?: string[]; 
  memberTargets?: Record<string, UserTarget>;
  currentTarget?: UserTarget;
}
