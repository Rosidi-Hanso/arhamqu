
import React, { useState, useEffect } from 'react';
import { Book, Layers, Users, X, Loader2, Menu, LayoutList } from 'lucide-react';
import { AppTab, Surah, Verse } from './types';
import { SurahList } from './components/SurahList';
import { JuzList } from './components/JuzList';
import { Halaqoh } from './components/Halaqoh';
import { apiService } from './services/apiService';

export const ArhamQuLogo = ({ className = "w-12 h-12" }: { className?: string }) => (
  <svg viewBox="0 0 100 100" className={className} xmlns="http://www.w3.org/2000/svg">
    <rect width="100" height="100" rx="30" fill="#1a4d36" />
    <text 
      x="50" 
      y="65" 
      textAnchor="middle" 
      fill="#f58220" 
      fontSize="42" 
      fontWeight="900" 
      fontFamily="sans-serif"
      style={{ letterSpacing: '-2px' }}
    >
      AQU
    </text>
  </svg>
);

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.SURAH);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [loadingVerses, setLoadingVerses] = useState(false);

  useEffect(() => {
    if (selectedSurah) {
      const fetchVerses = async () => {
        setLoadingVerses(true);
        const data = await apiService.getVerses(selectedSurah.nomor);
        setVerses(data);
        setLoadingVerses(false);
      };
      fetchVerses();
    }
  }, [selectedSurah]);

  const navItems = [
    { id: AppTab.SURAH, label: 'SURAH', icon: Book },
    { id: AppTab.JUZ, label: 'JUZ', icon: Layers },
    { id: AppTab.HALAQOH, label: 'HALAQOH', icon: Users },
  ];

  const handleTabChange = (tab: AppTab) => {
    setActiveTab(tab);
    setSelectedSurah(null);
  };

  return (
    <div className="flex h-screen bg-[#1a4d36] overflow-hidden font-sans select-none">
      {/* Desktop Sidebar (Hidden on Mobile) */}
      <aside className="hidden md:flex flex-col w-64 bg-[#1a4d36] text-white shrink-0 border-r border-black/10">
        <div className="p-8">
          <div className="flex items-center gap-3">
            <ArhamQuLogo className="w-12 h-12 shadow-lg shadow-black/20" />
            <div className="flex flex-col">
              <h1 className="text-xl font-black tracking-tighter text-white leading-none">ARHAM</h1>
              <h1 className="text-sm font-black tracking-[0.15em] text-[#f58220] leading-none mt-1">QUR'AN</h1>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 px-4 py-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleTabChange(item.id)}
              className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl transition-all duration-300 group ${
                activeTab === item.id 
                  ? 'bg-white text-[#1a4d36] shadow-xl shadow-black/10' 
                  : 'text-emerald-100 hover:bg-emerald-800/50'
              }`}
            >
              <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-[#1a4d36]' : 'text-emerald-300 group-hover:text-white'}`} />
              <span className="font-bold text-sm tracking-wide uppercase">{item.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content Container */}
      <div className="flex-1 flex flex-col h-full relative overflow-hidden bg-white md:m-3 md:rounded-[2.5rem]">
        {/* Mobile Header */}
        <header className="md:hidden bg-[#1a4d36] text-white pt-4 pb-3 px-5 shadow-lg z-30 shrink-0">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <ArhamQuLogo className="w-9 h-9" />
              <div className="flex flex-col">
                <h1 className="text-lg font-black tracking-tighter leading-none">ARHAM</h1>
                <h1 className="text-[10px] font-black tracking-widest text-[#f58220] leading-none mt-1">QUR'AN</h1>
              </div>
            </div>
            <div className="flex items-center gap-2">
               <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse mr-2" />
               <button className="p-2 bg-white/10 rounded-xl active:bg-white/20">
                 <Menu className="w-6 h-6 text-white" />
               </button>
            </div>
          </div>
        </header>

        {/* Viewport */}
        <main className="flex-1 overflow-hidden relative">
          {activeTab === AppTab.SURAH && <SurahList onSelectSurah={setSelectedSurah} />}
          {activeTab === AppTab.JUZ && <JuzList />}
          {activeTab === AppTab.HALAQOH && <Halaqoh />}

          {/* Surah Detail Overlay */}
          {selectedSurah && (
            <div className="absolute inset-0 bg-white z-[60] flex flex-col animate-in slide-in-from-bottom duration-300 overflow-hidden md:rounded-[2.5rem]">
              {/* Header Details */}
              <div className="p-4 bg-[#1a4d36] text-white flex items-center justify-between sticky top-0 z-10 shadow-lg shrink-0">
                <div className="flex items-center gap-4">
                  <button onClick={() => setSelectedSurah(null)} className="p-2 hover:bg-white/10 rounded-full transition-all active:scale-90">
                    <X className="w-6 h-6" />
                  </button>
                  <div className="hidden md:block">
                     <p className="text-[10px] font-black tracking-widest uppercase opacity-70">Satu Surah Penuh</p>
                  </div>
                </div>

                <div className="text-center">
                  <h2 className="font-black uppercase tracking-widest text-sm">{selectedSurah.namaLatin}</h2>
                  <p className="text-[10px] font-bold opacity-70 mt-0.5">{selectedSurah.arti} • {selectedSurah.jumlahAyat} Ayat</p>
                </div>
                
                <button className="hidden md:flex items-center gap-2 bg-black/20 hover:bg-black/30 px-6 py-2 rounded-full border border-white/10 transition-all active:scale-95">
                  <LayoutList className="w-4 h-4 text-emerald-300" />
                  <span className="text-[10px] font-black tracking-widest uppercase">MODE DAFTAR AYAT</span>
                </button>
                <div className="w-10 md:hidden" />
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 md:p-16 bg-[#f8faf9] custom-scrollbar">
                <div className="max-w-4xl mx-auto">
                  {loadingVerses ? (
                    <div className="h-full flex flex-col items-center justify-center gap-4 text-emerald-600 py-32">
                      <Loader2 className="w-10 h-10 animate-spin" />
                      <p className="text-[10px] font-black tracking-widest uppercase animate-pulse">Memuat Kalamullah...</p>
                    </div>
                  ) : (
                    <div className="space-y-24">
                      <div className="text-center py-10 mb-10">
                        {selectedSurah.nomor !== 1 && selectedSurah.nomor !== 9 && (
                          <p className="font-arabic text-5xl md:text-6xl text-emerald-900 mb-6 drop-shadow-sm leading-relaxed">
                            بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ
                          </p>
                        )}
                        <p className="text-[11px] text-gray-400 font-bold italic tracking-wide uppercase opacity-60">
                          "Dengan menyebut nama Allah Yang Maha Pengasih lagi Maha Penyayang"
                        </p>
                      </div>

                      {verses.map(v => (
                        <div key={v.nomorAyat} className="relative group transition-all duration-500">
                          {/* Verse Badge - Circular style */}
                          <div className="absolute -left-4 md:-left-16 top-0 z-10">
                             <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-[11px] font-black text-white shadow-lg shadow-emerald-500/30 border-2 border-white transition-transform group-hover:scale-110">
                               {v.nomorAyat}
                             </div>
                          </div>

                          {/* Arabic Text - Desktop Optimized */}
                          <div className="flex justify-end mb-10 pl-8 md:pl-0">
                            <p className="font-arabic text-4xl md:text-6xl text-right leading-[5.5rem] md:leading-[8rem] text-gray-900 flex-1 tracking-wide drop-shadow-sm transition-all group-hover:text-emerald-950">
                              {v.teksArab}
                            </p>
                          </div>

                          {/* Translation Card - Desktop Optimized */}
                          <div className="flex justify-center w-full">
                             <div className="bg-white p-8 md:p-10 rounded-[2.5rem] border-l-[6px] border-emerald-400 shadow-[0_10px_40px_-15px_rgba(0,0,0,0.05)] w-full max-w-2xl transform transition-all duration-500 group-hover:-translate-y-1 group-hover:shadow-emerald-900/5">
                               <p className="text-emerald-700 text-[11px] md:text-[12px] mb-4 font-black leading-relaxed opacity-80 italic">
                                 {v.teksLatin}
                               </p>
                               <p className="text-gray-700 text-sm md:text-base leading-[1.8] font-medium tracking-tight">
                                 {v.teksIndonesia}
                               </p>
                             </div>
                          </div>
                        </div>
                      ))}

                      <div className="py-24 text-center">
                         <p className="text-emerald-400 text-xs font-black tracking-[0.5em] uppercase italic opacity-40">Sadaqallahul 'Adzim</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Mobile Navigation */}
        <nav className="md:hidden bg-white border-t border-gray-100 flex items-center justify-around px-2 py-3 pb-6 z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.03)] shrink-0">
          {navItems.map((item) => (
            <button 
              key={item.id}
              onClick={() => handleTabChange(item.id)}
              className={`flex flex-col items-center p-2 min-w-[64px] transition-all duration-300 ${activeTab === item.id ? 'text-[#1a4d36] scale-105' : 'text-gray-300'}`}
            >
              <item.icon className={`w-6 h-6 ${activeTab === item.id ? 'fill-emerald-600/5' : ''}`} />
              <span className="text-[8px] mt-1.5 font-black uppercase tracking-tighter">{item.label}</span>
              {activeTab === item.id && <div className="w-1 h-1 bg-[#f58220] rounded-full mt-1" />}
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default App;
